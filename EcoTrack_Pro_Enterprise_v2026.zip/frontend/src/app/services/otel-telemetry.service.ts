import { WebTracerProvider } from '@opentelemetry/sdk-trace-web';
// OTel Web SDK Initialization