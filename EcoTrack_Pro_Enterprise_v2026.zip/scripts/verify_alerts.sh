#!/bin/bash
# Script to trigger budget and infrastructure alerts.